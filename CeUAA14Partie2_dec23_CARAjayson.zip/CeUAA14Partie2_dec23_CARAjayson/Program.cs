﻿// See https://aka.ms/new-console-template for more information
using CeUAA14Partie2_dec23_CARAjayson;

Console.WriteLine("Bienvenue dans ce jeu de tir ... Vous démarrez avec 30 munnitions");
Console.WriteLine("=================================================================");
Console.WriteLine("Vous avez un total de 30 munitions dans vos poches et 0 munition dans le chargeur\nAttention votre chargeur est vide !\n\nEspace pour tirer,\nr pour recharger,\n+ pour demander un ravitaillement,\ni pour voir votre inventaire,\nq pour quitter.");
string userInput = "";
PaintBallGun Player = new PaintBallGun(30,0);
do
{
    userInput = Console.ReadLine();
    if (userInput == "r")
    {     
        Console.WriteLine(Player.reload(ref Player._AmmoP,ref Player._AmmoC));
    }
    else if (userInput == "+")
    {
        Player.supply(ref Player._AmmoP);
        Console.WriteLine(" Ravitaillement effectuer ! ");
    }
    else if (userInput == " ")
    {
        Console.WriteLine(Player.fire(ref Player._AmmoC));
    }
    else if (userInput == "i")
    {
        
        Console.WriteLine(Player.inventory(Player._AmmoC, Player._AmmoP));
    }
} while (userInput != "q");
