﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CeUAA14Partie2_dec23_CARAjayson
{
    internal class PaintBallGun
    {
        public uint _AmmoP;
        public uint _AmmoC;

        public PaintBallGun(uint AmmoP, uint AmmoC) 
        {
            _AmmoP = AmmoP;
            _AmmoC = AmmoC;
        }

        public uint AmmoP
        {
            get 
            { 
                return _AmmoP; 
            }
            set 
            { 
                _AmmoP = value; 
            }
        }
        public uint AmmoC
        {
            get
            {
                return _AmmoC;
            }
            set 
            { 
                _AmmoC = value; 
            }
        }

        public string reload(ref uint AmmoP,ref uint AmmoC)
        {
            string message = "";
            if (AmmoC == 16) 
            {
                message = " Le chargeur est plein ! ";
                
            }
            else if (AmmoP == 0)
            {
                message = " Vous n'avez plus de munition à mettre dans le chargeur ! Demander un ravitaillement ? (+) ";
            }
            else
            {
                do
                {
                    AmmoC++;
                    AmmoP--;
                } while (AmmoP != 0 && AmmoC != 16);
                if (AmmoC == 16) 
                {
                    message = " rechargement effectuer entierement ! ";
                }
                else
                {
                    message = " rechergement effectuer partielment ! ";
                }
            }
            return message;
        }

        public string fire(ref uint AmmoC)
        {
            string message = "";
            if (_AmmoC == 0) 
            {
                message = " Le chargeur est vide ! ";
            }
            else
            {
                AmmoC--;
                message = " PIOU ! ";
            }
            return message;
        }

        public void supply(ref uint AmmoP)
        {
            AmmoP += 30;
        }

        public string inventory(uint AmmoC, uint AmmoP) 
        {
            string message = " Vous avez " + _AmmoC + " munition(s) dans votre chargeur et vous avez " + _AmmoP + " munition(s) dans votre vos poches ! ";
            return message;
        }
    }
}
